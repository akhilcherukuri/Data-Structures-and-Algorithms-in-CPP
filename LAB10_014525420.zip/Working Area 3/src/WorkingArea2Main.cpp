#define SIZE 10
#include <iostream>
#include <cstdlib>

using namespace std;

template <class X>
class queue
{
	X *arr;
	int capacity;
	int front;
	int rear;
	int count;

public:
	queue(int size = SIZE);

	void pop_queue();
	void push_queue(X x);
	void empty_queue();
	int size_queue();
	bool isEmpty();
	bool isFull();
};


template <class X>
queue<X>::queue(int size)
{
	arr = new X[size];
	capacity = size;
	front = 0;
	rear = -1;
	count = 0;
}

template <class X>
void queue<X>::pop_queue()
{
	if (isEmpty())
	{
		cout << "UnderFlow \n Program Terminated \n";
		exit(EXIT_FAILURE);
	}

	cout << "POPING " << arr[front] << " FROM QUEUE \n";

	front = (front + 1) % capacity;
	count--;
}


template <class X>
void queue<X>::push_queue(X item)
{
	// check for queue overflow
	if (isFull())
	{
		cout << "OverFlow\nProgram Terminated\n";
		exit(EXIT_FAILURE);
	}

	cout << "PUSHING " << item <<  " TO QUEUE \n";

	rear = (rear + 1) % capacity;
	arr[rear] = item;
	count++;
}


template <class X>
int queue<X>::size_queue()
{
	return count;
}

template <class X>
bool queue<X>::isEmpty()
{
	return (size_queue() == 0);
}

template <class X>
bool queue<X>::isFull()
{
	return (size_queue() == capacity);
}

template <class X>
void queue<X>::empty_queue(){
	front = 0;
	rear = -1;
	count = 0;
}

int main()
{
	queue<string> q(10);

	q.push_queue("a");
	q.push_queue("b");
	q.push_queue("c");

	cout << "QUEUE SIZE: " << q.size_queue() << endl;

	q.pop_queue();

	cout << "QUEUE SIZE: " << q.size_queue() << endl;

	cout << "EMPTYING QUEUE NOW"<< endl;
	q.empty_queue();

	cout << "QUEUE SIZE: " << q.size_queue() << endl;

	if (q.isEmpty())
		cout << "QUEUE IS EMPTY \n";
	else
		cout << "QUEUE Is EMPTY \n";

	return 0;
}
